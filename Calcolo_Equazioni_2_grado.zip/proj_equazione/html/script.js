document.getElementById('calculate-btn').addEventListener('click', function() {
  const a = parseFloat(document.getElementById('coeff-a').value);
  const b = parseFloat(document.getElementById('coeff-b').value);
  const c = parseFloat(document.getElementById('coeff-c').value);
  
  const delta = b * b - 4 * a * c;
  const resultDiv = document.getElementById('result');
  
  if (delta < 0) {
      resultDiv.textContent = "L'equazione non possiede soluzioni nel campo dei numeri Reali.";
      resultDiv.style.color = "red";
  } else {
      const x1 = (-b + Math.sqrt(delta)) / (2 * a);
      const x2 = (-b - Math.sqrt(delta)) / (2 * a);
      resultDiv.innerHTML = `Soluzioni reali: <br> x₁ = ${x1.toFixed(3)}, x₂ = ${x2.toFixed(3)}`;
      resultDiv.style.color = "lightgreen";
  }
});
