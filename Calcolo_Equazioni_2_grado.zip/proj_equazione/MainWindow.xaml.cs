﻿using System.Windows;
using System.Windows.Input;
using Microsoft.Web.WebView2.Core;

namespace equazione2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
            InitializeComponent();

            this.Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {

            webView.CoreWebView2InitializationCompleted += (sender, args) =>
            {
                if (args.IsSuccess)
                {
                    webView.CoreWebView2.PermissionRequested += (sender, args) =>
                    {
                        if (args.PermissionKind == CoreWebView2PermissionKind.Geolocation)
                        {
                            args.State = CoreWebView2PermissionState.Allow;
                        }
                    };
                }
            };
            
            webView.EnsureCoreWebView2Async(null);
           

            string path = System.IO.Path.Combine(Environment.CurrentDirectory, "html", "index.html");
            webView.Source = new Uri(path);
        }

        private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Questo permette di spostare la finestra trascinando la barra del titolo personalizzata
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }


    }
}
