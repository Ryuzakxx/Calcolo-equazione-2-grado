In questo file .zip sono presenti 2 cartelle, una per eseguire
l'applicazione dal .exe, l'altra per aprire il progetto dell'applicazione
su Visual Studio 2022. L'applicazione è stata creata con .NET 8.0, utilizzando
la webview.